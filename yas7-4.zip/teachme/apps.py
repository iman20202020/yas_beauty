from django.apps import AppConfig


class TeachmeConfig(AppConfig):
    name = 'teachme'
